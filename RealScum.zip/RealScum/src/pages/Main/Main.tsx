import { Route, Routes } from 'react-router-dom'
import style from './Main.module.css';
import { NOUDONT, instance1} from '../../api'
import Larr from "../../images/ArrowL.png"
import Rarr from "../../images/ArrowR.png"
import { useEffect, useState } from 'react';
import { bigTablo } from '../../components/BigTablo/midGame';

const Main = () => {

    const [gamegame,setGamegame] = useState<[]>()
    const [isLoading, setIsLoading] = useState<boolean>(false)
    

   /*  useEffect(() => {
        setIsLoading(true)
        instance1.get('https://6634f8309bb0df2359a36312.mockapi.io/api/apps/apps').then(({ data }) => {
            setGamegame(data)
            console.log(data)
            

            setTimeout(() => {
                setIsLoading(false)
            }, 700)
        })
    }, []) */

    return (
       
        
        <div className={style.center}>
            <p className={style.tx}>POPULAR AND RECOMMENDED</p>
            <div className={style.stoiRovno}>
                <img src={Larr} alt="strelkal" className={style.streloski} />
                <div className={style.megaBox}>
                <>
                {/* {bigTablo(gamegame)} */}
                </>
                </div>
                <img src={Rarr} alt="strelkar" className={style.streloskir}/>
            </div>
        </div>
    )
}
export default Main