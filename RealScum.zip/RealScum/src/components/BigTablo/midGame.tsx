import style from '../../pages/Main/Main.module.css';



export const bigTablo = (a: any) => {
    console.log("gamegame", a)

    interface MainInterface {
        title: string
        price: string
        image1: string
        image2?: string
        image3?: string
        image4?: string
        image5?: string
        image6?: string
    }

    return (
        <>
            {a.map((item: MainInterface, index: number) => (
                <div className={style.in_a_row}>
                    <img className={style.bigImg} src={item.image1} alt="" />
                    <div className={style.Zaraighter}>
                        <h2>{item.title}</h2>
                        <div className={style.kvadrat}>
                            <img className={style.to_the_right_img} src={item.image3} alt="" />
                            <img className={style.to_the_right_img} src={item.image4} alt="" />
                            <img className={style.to_the_right_img} src={item.image5} alt="" />
                            <img className={style.to_the_right_img} src={item.image6} alt="" />
                        </div>
                        <h3>{item.price}</h3>
                    </div>
                </div>
            ))}
        </>
    )
}